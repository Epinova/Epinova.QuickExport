﻿define([
    "dojo/topic",
    "dojo/_base/declare",
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi/i18n!epi/nls/epinovaquickexport.widget"
], function (
    topic,
    declare,
    dependency,
    _Command,
    translator
) {
    return declare([_Command], {
        name: "export",
        label: translator.button.label,
        tooltip: translator.button.tooltip,
        iconClass: "epi-iconDownload",
        canExecute: true,

        _execute: function () {
            dojo.rawXhrPost({
                url: '/QuickExport/Export',
                handleAs: 'json',
                headers: { "Content-Type": 'application/json' },
                timeout: 60000,
                postData: dojo.toJson({ 'id': this.model.contentLink }),
                load: function (data) {
                    if (!!data && !!data.success) {
                        window.location = '/QuickExport/Download?id=' + data.id;
                    } else {
                        alert(translator.errors.generic);
                    }
                },
                error: function (error) {
                    alert(translator.errors.download + ': ' + error);
                }
            });
        }
    });
});