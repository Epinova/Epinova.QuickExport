﻿define([
    "dojo",
    "epi/dependency",
    "epi-cms/plugin-area/navigation-tree",
    "epinova-quickexport/ExportCommand"
],
function (
    dojo,
    dependency,
    navigationTreePluginArea,
    ExportCommand
) {
    return dojo.declare([], {
        initialize: function () {
            navigationTreePluginArea.add(ExportCommand);
        }
    });
});